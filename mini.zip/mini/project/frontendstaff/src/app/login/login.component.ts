import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Staff } from '../model/staff';
import { StaffService } from '../service/staff.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user = new Staff();
  msg="";
  Staff: Staff;

  constructor(private staffService: StaffService, private _router : Router) { }

  ngOnInit(): void {
  }

  loginStaff(){
    this.staffService.loginStaffFromRemote(this.Staff).subscribe(
      (data: Staff) => {
        console.log("response received");
        console.log(data);
        localStorage.setItem('staffid', String(data.staffId));
        localStorage.setItem('staffname', data.staffName);
        localStorage.setItem('password', data.password);
        localStorage.setItem('role', data.role);

        this._router.navigate(['/landing-page/staff-list'])
      },
      error => {
        console.log("exception occured");
        this.msg = "Bad Credential, Please enter valid user name and password";
      }
    );
  }
  staff(staff: any) {
    throw new Error('Method not implemented.');
  }

  gotoregistration(){
    this._router.navigate(['/registration'])
  }

}
