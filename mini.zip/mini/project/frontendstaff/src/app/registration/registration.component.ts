import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Staff } from '../model/staff';
import { NgForm } from '@angular/forms';
import { StaffService } from '../service/staff.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  staff = new Staff();
  msg='';

  constructor(private _service : StaffService , private _router : Router) { }

  ngOnInit(): void {
  }


  registerStaff(){
    this._service.registerStaffFromRemote(this.staff).subscribe(
      data => {
        console.log("Response Received");
        this._router.navigate(['/login']);
        // this.msg="Registration Successful";
      }
      ,
      error => {
        console.log("exception occured");
        this.msg=error.error;
      }
    )
  }

}
