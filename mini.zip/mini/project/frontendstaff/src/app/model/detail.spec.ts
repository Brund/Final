import { Detail } from './detail';

describe('Detail', () => {
  it('should create an instance', () => {
    expect(new Detail()).toBeTruthy();
  });
});
