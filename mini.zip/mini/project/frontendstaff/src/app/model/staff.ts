export class Staff {
  subscribe(arg0: (data: Staff) => void, arg1: (error: any) => void) {
    throw new Error('Method not implemented.');
  }

  staffId: number;
  staffName: string;
  type: String;
  bname:String;
  password: string;
  role: string;



}
