import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Staff } from '../app/model/staff';

@Injectable({
  providedIn: 'root'
})

export class StaffService {

  private baseUrl="http://localhost:8080/user";

  constructor(private httpClient: HttpClient) { }

  getStaffList(): Observable<Staff[]>{
    return this.httpClient.get<Staff[]>(`${this.baseUrl}`);
  }

  createStaff(staff:Staff): Observable<Object>{
    return this.httpClient.post(`${this.baseUrl}`, staff);
  }

}
