import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Detail } from 'src/app/model/detail';
import { DetailService } from 'src/app/service/detail.service';

@Component({
  selector: 'app-update-detail',
  templateUrl: './update-detail.component.html',
  styleUrls: ['./update-detail.component.css']
})
export class UpdateDetailComponent implements OnInit {
  id: number;
  patient: Detail = new Detail();
  detail: Detail;
  constructor(private detailService: DetailService, private route: ActivatedRoute, private router:Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.detailService.getDetailById(this.id).subscribe(
      data => {
        this.detail=data;
      }, error => console.log(error)
    );
  }
  saveUser(){
    this.detailService.updateDetail(this.id, this.patient).subscribe(data =>{
        this.goToStaffList();
    }, error => console.log(error));
  }

  goToStaffList(){
    this.router.navigate(['/landing-page/detail-list'])
  }

}
