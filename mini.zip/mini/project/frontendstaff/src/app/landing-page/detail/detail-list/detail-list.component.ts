import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Detail } from 'src/app/model/detail';
import { DetailService } from 'src/app/service/detail.service';

@Component({
  selector: 'app-detail-list',
  templateUrl: './detail-list.component.html',
  styleUrls: ['./detail-list.component.css']
})
export class DetailListComponent implements OnInit {

  patients: Detail[];
  details: any;
  constructor(private detailService: DetailService, private router: Router) { }

  ngOnInit(): void {
    this.getDetails();
  }

  private getDetails(){
    // debugger
    this.detailService.getDetailList().subscribe(data => {
      this.details = data;
      for(let i=0; i<this.details.length; i++){
        this.details[i]['type']="password";
        this.details[i]['bname']="Show";
      }
    });
  }

  updateDetail(id: number){
    console.log(id);
    this.router.navigate(['/landing-page/update-detail', id]);
  }

  deleteDetail(id: number){
    // console.log(id);
    // this.router.navigate(['/landing-page/delete-staff', id]);
    this.detailService.deleteDetail(id).subscribe(
      data => {
        console.log(data);
        this.getDetails();
      }, error => {
        console.log("Not Delete")
      }
    )
  }


  showpassword(type:any,index:any){
    // this.admins[index].type='text'

    if(type=='text'){
      this.details[index].type='password'
      this.details[index].bname='Show'
    } else{
      this.details[index].type='text'
      this.details[index].bname='Hide'
    }

  }

}
