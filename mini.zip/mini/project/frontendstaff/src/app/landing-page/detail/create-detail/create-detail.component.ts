import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Detail } from 'src/app/model/detail';
import { DetailService } from 'src/app/service/detail.service';

@Component({
  selector: 'app-create-detail',
  templateUrl: './create-detail.component.html',
  styleUrls: ['./create-detail.component.css']
})
export class CreateDetailComponent implements OnInit {

  patient: Detail = new Detail();
  detail: Detail;

  constructor(private detailService: DetailService, private router: Router) { }

  ngOnInit(): void {
  }

  saveStaff(){
    this.detailService.createDetail(this.detail).subscribe(data=>{
      console.log(data);
      this.goToStaffList();
    }, error => console.log(error));
  }
 

  goToStaffList(){
    this.router.navigate(['/landing-page/detail-list']);
  }

}
