import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LandingPageRoutingModule } from './landing-page-routing.module';
import { LandingPageComponent } from './landing-page.component';

import { CreateUserComponent } from './staff/create-staff/create-staff.component';
import { UpdateUserComponent } from './staff/update-staff/update-staff.component';
import { StaffListComponent } from './staff/staff-list/staff-list.component';
import { FormsModule } from '@angular/forms';
// import { DoctorListComponent } from './doctor/doctor-list/doctor-list.component';
// import { CreateDoctorComponent } from './doctor/create-doctor/create-doctor.component';
// import { UpdateDoctorComponent } from './doctor/update-doctor/update-doctor.component';
// import { AdminListComponent } from './admin/admin-list/admin-list.component';
// import { CreateAdminComponent } from './admin/create-admin/create-admin.component';
// import { UpdateAdminComponent } from './admin/update-admin/update-admin.component';
// import { AppointmentListComponent } from './appointment/appointment-list/appointment-list.component';
// import { CreateAppointmentComponent } from './appointment/create-appointment/create-appointment.component';
// import { UpdateAppointmentComponent } from './appointment/update-appointment/update-appointment.component';
// import { AvailabilityListComponent } from './availabilitydates/availability-list/availability-list.component';
// import { CreateAvailabilityComponent } from './availabilitydates/create-availability/create-availability.component';
// import { UpdateAvailabilityComponent } from './availabilitydates/update-availability/update-availability.component';
// import { FeedbackListComponent } from './feedback/feedback-list/feedback-list.component';
// import { CreateFeedbackComponent } from './feedback/create-feedback/create-feedback.component';
// import { UpdateFeedbackComponent } from './feedback/update-feedback/update-feedback.component';
import { DetailListComponent } from './detail/detail-list/detail-list.component';
import { CreateDetailComponent } from './detail/create-detail/create-detail.component';

import { UpdateDetailComponent } from './detail/update-detail/update-detail.component';





@NgModule({
  declarations: [
    LandingPageComponent,

    CreateDetailComponent,
    UpdateDetailComponent,
    StaffListComponent,
    // DoctorListComponent,
    // CreateDoctorComponent,
    // UpdateDoctorComponent,
    // AdminListComponent,
    // CreateAdminComponent,
    // UpdateAdminComponent,
    // AppointmentListComponent,
    // CreateAppointmentComponent,
    // UpdateAppointmentComponent,
    // AvailabilityListComponent,
    // CreateAvailabilityComponent,
    // UpdateAvailabilityComponent,
    // FeedbackListComponent,
    // CreateFeedbackComponent,
    // UpdateFeedbackComponent,
    DetailListComponent,
    CreateDetailComponent,

    UpdateDetailComponent,


  ],
  imports: [
    CommonModule,
    LandingPageRoutingModule,
    FormsModule,

  ]
})
export class LandingPageModule { }
