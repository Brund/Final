import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Staff } from '../../../model/staff';
import { StaffService } from '../../../service/staff.service';

@Component({
  selector: 'app-create-staff',
  templateUrl: './create-staff.component.html',
  styleUrls: ['./create-staff.component.css']
})
export class CreateUserComponent implements OnInit {

  staff: Staff = new Staff();
  Staff: any;
  detail: any;


  constructor(private staffService: StaffService, private router: Router) { }

  ngOnInit(): void {
  }

  saveStaff(){
    this.staffService.createStaff().subscribe(data=>{
      console.log(data);
      this.goToStaffList();
    }, error => console.log(error));
  }

  goToStaffList(){
    this.router.navigate(['/landing-page/staff-list'])
  }

  onSubmit(){
    console.log(this.staff);
    this.saveStaff;

  }
}
function subscribe(arg0: (data: any) => void, arg1: (error: any) => void) {
  throw new Error('Function not implemented.');
}

