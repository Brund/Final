import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Staff } from '../../../model/staff';
import { StaffService } from '../../../service/staff.service';

@Component({
  selector: 'app-staff-list',
  templateUrl: './staff-list.component.html',
  styleUrls: ['./staff-list.component.css']
})
export class StaffListComponent implements OnInit {

  staffs: Staff[];



  constructor(private staffService: StaffService, private router: Router) { }

  ngOnInit(): void {

    this.checkLogin();

    this.getStaffs();
  }

  private getStaffs(){
    // debugger
    this.staffService.getStaffList().subscribe(data => {
      this.staffs = data;

      for(let i=0; i<this.staffs.length; i++){
        this.staffs[i]['type']="password";
        this.staffs[i]['bname']="Show";
      }

    });
  }
  updateStaff(id: number){
    console.log(id);
    this.router.navigate(['/landing-page/update-staff', id]);
  }

  deleteStaff(id: number){
    // console.log(id);
    // this.router.navigate(['/landing-page/delete-staff', id]);
    this.staffService.deleteStaff(id).subscribe(
      data => {
        console.log(data);
        this.getStaffs();
      }, error => {
        console.log("Not Delete")
      }
    )
  }

  checkLogin(){

  //Local storage Start
   const staffid =  localStorage.getItem('staffid');
   const staffname =  localStorage.getItem('staffname');
   const password =  localStorage.getItem('password');
   const role =  localStorage.getItem('role');
   console.log(staffname);


   let staff = new Staff();
    staff.staffId=Number(staffid);
    staff.staffName=String(staffname);
    staff.password=String(password);
    staff.role=String(role);
    this.staffService.loginStaffFromRemote(staff).subscribe(
      (data: Staff) => {
        return true;
      },

        error => {
          this.router.navigate(['/login']);

      }
    );
}


showpassword(type:any,index:any){
  // this.admins[index].type='text'

  if(type=='text'){
    this.staffs[index].type='password'
    this.staffs[index].bname='Show'
  } else{
    this.staffs[index].type='text'
    this.staffs[index].bname='Hide'
  }

}

}
