 export interface IDetail{
  staffId: number;
  staffName: string;
  password: string;
  role: string;
}
