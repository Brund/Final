import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Staff } from '../model/staff';

@Injectable({
  providedIn: 'root'
})

export class StaffService {

  private baseUrl="http://localhost:8080/staff";

  constructor(private httpClient: HttpClient) { }

  getStaffList(): Observable<Staff[]>{
    return this.httpClient.get<Staff[]>(`${this.baseUrl}`);
  }

  createStaff(): Observable<Object>{
    return this.httpClient.post("http://localhost:8080/registerstaff", Staff);
  }

  public loginStaffFromRemote(staff : Staff):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/login", Staff)
  }

  public registerStaffFromRemote(staff : Staff):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/registerstaff", Staff)
  }

  getStaffById(id: number): Observable<Staff>{
    return this.httpClient.get<Staff>(`${this.baseUrl}/${id}`);
  }

  updateStaff(): Observable<Object>{
  return this.httpClient.put(`${this.baseUrl}`,Staff);
}

deleteStaff(id: number): Observable<Object>{
  return this.httpClient.delete(`${this.baseUrl}/${id}`);
}

}
function registerStaffFromRemote(staff: any, Detail: typeof Staff) {
  throw new Error('Function not implemented.');
}

