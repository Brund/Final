import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Detail } from '../model/detail';

@Injectable({
  providedIn: 'root'
})
export class DetailService {
  private baseUrl="http://localhost:8080/patient";
  constructor(private httpclient: HttpClient) { }


  createDetail(detail:Detail): Observable<any>{
    return this.httpclient.post<any>(`${this.baseUrl}`, detail);
  }
  getDetailList(): Observable<Detail[]>{
    return this.httpclient.get<Detail[]>(`${this.baseUrl}`);
  }
  getDetailById(id: number): Observable<Detail>{
    return this.httpclient.get<Detail>(`${this.baseUrl}/${id}`);
  }
  updateDetail(id: number, doctor: Detail): Observable<Object>{
    return this.httpclient.put(`${this.baseUrl}`,doctor);
  }

  deleteDetail(id: number): Observable<Object>{
    return this.httpclient.delete(`${this.baseUrl}/${id}`);
  }
}
