package com.crud.app.services;

import com.crud.app.model.Detail;
import com.crud.app.model.Staff;
import com.crud.app.repository.DetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DetailService {

    @Autowired
    private DetailRepository detailRepository;

    public List<Detail> listAll(){
        return detailRepository.findAll();
    }

    public Detail get(int id){
        return detailRepository.findById(id).get();

    }

    public void save(Detail detail){
        detailRepository.save(detail);
    }

    public Detail update(Detail detail){
        return detailRepository.save(detail);
    }

    public void delete(int id){
        detailRepository.deleteById(id);
    }

}
