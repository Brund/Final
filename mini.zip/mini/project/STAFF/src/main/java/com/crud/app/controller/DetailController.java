package com.crud.app.controller;

public class DetailController {

}
