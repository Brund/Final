package com.crud.app.repository;

import com.crud.app.model.Staff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StaffRepository extends JpaRepository<Staff, Integer> {
    public Staff findByStaffName(String staffName);
    public Staff findByStaffNameAndPassword(String staffName, String password);
}
