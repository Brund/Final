package com.crud.app.controller;

import com.crud.app.model.Staff;

import com.crud.app.services.StaffService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;

@RestController
//@CrossOrigin(origins = "http://localhost:4200")
@CrossOrigin("*")
@RequestMapping("/")
public class StaffController {

	 @Autowired
	    private StaffService staffService;

	    @PostMapping("/registerstaff")
	    public Staff RegistrationController(@RequestBody Staff staff) throws Exception {
	        String tempStaffName = staff.getStaffName();
	        if(tempStaffName!=null && !"".equals(tempStaffName)){
	            Staff staffobj = staffService.fetchStaffByStaffName(tempStaffName);
	            if(staffobj != null){
	                throw new Exception("staff with "+ tempStaffName + "is allready exist");
	            }
	        }
	        Staff staffObj =null;
	        staffObj = staffService.save(staff);
	        return staffObj;
	    }


	    @PostMapping("/login")
	    public  Staff loginStaff(@RequestBody Staff staff) throws Exception {
	        String tempStaffName=staff.getStaffName();
	        String tempPass = staff.getPassword();
	        Staff staffObj = null;
	        if(tempStaffName !=null && tempPass != null){
	            staffObj = staffService.fetchStaffByStaffNameAndPassword(tempStaffName,tempPass);
	        }
	        if (staffObj==null){
	            throw new Exception("bad credentials");
	        }
	        return staffObj;
	    }


	    @GetMapping("staff")
	    public List<Staff> list(){
	        return staffService.listAll();
	    }

	    @GetMapping("staff/{id}")
	    @CrossOrigin(origins = "http://localhost:4200")
	    public ResponseEntity<Staff> get(@PathVariable Integer id){
	        try{
	            Staff staff = staffService.get(id);
	            return new ResponseEntity<Staff>(staff, HttpStatus.OK);

	        } catch (NoSuchElementException e){
	            return new ResponseEntity<Staff>(HttpStatus.NOT_FOUND);
	        }

	    }

	    @PostMapping("staff")
	    public ResponseEntity<Staff> add(@RequestBody Staff staff ){
	        staffService.save(staff);
	        return new ResponseEntity<Staff>(staff,HttpStatus.CREATED);
	    }


	    @PutMapping("staff")
	    public ResponseEntity<?> update(@RequestBody Staff staff ) {
	        try {
	            Staff existStaff = staffService.update(staff);
	            staffService.save(staff);
	            return new ResponseEntity<>(HttpStatus.OK);
	        } catch (NoSuchElementException e) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }


//	    @PutMapping("user/{id}")
//	    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user){
//	        User userUpdate = userService.updateUser(id)
//	                .orElseThrow(()->new ConfigDataResourceNotFoundException(("Employee not exit with id : "+id));
	//
//	        userUpdate.setUserName(user.getUserName());
//	        userUpdate.setPassword(user.getPassword());
//	        userUpdate.setRole(user.getRole());
	//
//	        User u = userService.save(userUpdate);
//	        return ResponseEntity.ok(u);
	//
//	    }


	    @DeleteMapping("staff/{id}")
	    public void delete(@PathVariable Integer id) {
	        staffService.delete(id);
	    }



	}
